#!/bin/bash
./mvnw clean package
