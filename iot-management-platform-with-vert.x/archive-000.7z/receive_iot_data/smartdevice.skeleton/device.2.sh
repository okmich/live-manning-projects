#!/bin/bash
HTTP_PORT="8082" \
DEVICE_LOCATION="garden" \
DEVICE_ID="BVOP34" \
GATEWAY_TOKEN="smart.home" \
java -jar target/smartdevice-1.0.0-SNAPSHOT-fat.jar ;


