#!/bin/bash
HTTP_PORT="8083" \
DEVICE_LOCATION="bathroom" \
DEVICE_ID="OPRH67" \
GATEWAY_TOKEN="smart.home" \
java -jar target/smartdevice-1.0.0-SNAPSHOT-fat.jar ;


