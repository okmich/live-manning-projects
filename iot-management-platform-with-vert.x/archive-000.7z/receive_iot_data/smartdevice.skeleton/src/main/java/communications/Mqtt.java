package communications;

public interface Mqtt {

}
