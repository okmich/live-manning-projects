package communications;

public interface Http {

}
