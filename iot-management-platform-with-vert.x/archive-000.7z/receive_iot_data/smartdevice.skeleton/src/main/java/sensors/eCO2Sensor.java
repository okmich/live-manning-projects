package sensors;

public class eCO2Sensor implements Sensor {

}
