package sensors;

public class HumiditySensor implements Sensor {

}
