package sensors;

public class TemperatureSensor implements Sensor {

}
