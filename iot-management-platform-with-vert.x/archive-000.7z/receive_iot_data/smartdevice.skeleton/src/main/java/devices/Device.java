package devices;

public interface Device {

}
