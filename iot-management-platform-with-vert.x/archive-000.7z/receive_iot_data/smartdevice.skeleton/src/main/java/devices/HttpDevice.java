package devices;

import communications.Http;

public class HttpDevice implements Device, Http {

}
